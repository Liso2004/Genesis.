using UnityEngine;
using System.Collections;

namespace Genesis.Character
{
    [RequireComponent(typeof(CharacterController))]
    [RequireComponent(typeof(GenesisActor))]
    public sealed class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] private float walkSpeed = 3f;
        [SerializeField] private float runSpeed = 6f;
        [SerializeField] private float rotationSpeed = 12f;

        [Header("Camera")]
        [SerializeField] private Transform cameraTransform;

        [Header("Jump")]
        [SerializeField] private float jumpHeight = 1.8f;
        [SerializeField] private float gravity = -20f;

        [Header("Animation")]
        [SerializeField] private Animator animator;

        [Header("Ground Check")]
        [SerializeField] private float groundCheckDistance = 0.3f;
        [SerializeField] private LayerMask groundLayerMask = ~0;

        [Header("Jump Delay")]
        [SerializeField] private float jumpDelay = 0.05f; // Adjust this for anticipation

        private CharacterController _controller;
        private float _verticalVelocity;
        private bool _isGrounded;
        private bool _isRunning;
        private bool _isJumping;

        private void Awake()
        {
            _controller = GetComponent<CharacterController>();

            // Force the player to the ground level if it's floating
            Vector3 pos = transform.position;
            pos.y = 0f;
            transform.position = pos;

            // Fix the Character Controller so the capsule sits on the ground
            _controller.center = new Vector3(0, _controller.height / 2f, 0);
            _controller.skinWidth = 0.08f;
            _controller.stepOffset = 0.1f;

            if (cameraTransform == null && Camera.main != null)
                cameraTransform = Camera.main.transform;

            if (animator == null)
                animator = GetComponentInChildren<Animator>();
        }

        private void Update()
        {
            HandleMovement();
            UpdateAnimation();
        }

        private void HandleMovement()
        {
            // Ground detection using a raycast
            CheckGround();

            if (_isGrounded && _verticalVelocity < 0f) _verticalVelocity = -2f;

            // RUN uses Shift
            _isRunning = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);

            float horizontal = Input.GetAxisRaw("Horizontal");
            float vertical = Input.GetAxisRaw("Vertical");
            Vector3 input = new Vector3(horizontal, 0f, vertical);
            input = Vector3.ClampMagnitude(input, 1f);

            Vector3 movementDirection = Vector3.zero;
            if (input.sqrMagnitude > 0.001f)
            {
                if (cameraTransform != null)
                {
                    Vector3 cameraForward = cameraTransform.forward;
                    Vector3 cameraRight = cameraTransform.right;
                    cameraForward.y = 0f; cameraRight.y = 0f;
                    cameraForward.Normalize(); cameraRight.Normalize();
                    movementDirection = cameraForward * input.z + cameraRight * input.x;
                }
                else
                {
                    movementDirection = new Vector3(input.x, 0f, input.z);
                }
                movementDirection.Normalize();
                RotateToward(movementDirection);
            }

            // Jump handling with anticipation delay
            HandleJump();

            // ** APPLY GRAVITY WHEN NOT GROUNDED **
            if (!_isGrounded)
            {
                _verticalVelocity += gravity * Time.deltaTime;
            }

            float currentSpeed = _isRunning ? runSpeed : walkSpeed;
            Vector3 movement = movementDirection * currentSpeed;
            movement.y = _verticalVelocity;
            _controller.Move(movement * Time.deltaTime);
        }

        private void CheckGround()
        {
            Vector3 start = transform.position + Vector3.up * 0.1f;
            float rayDistance = groundCheckDistance + 0.5f;

            if (Physics.Raycast(start, Vector3.down, out RaycastHit hit, rayDistance, groundLayerMask))
            {
                _isGrounded = true;
            }
            else
            {
                _isGrounded = false;
            }
        }

        private void HandleJump()
        {
            // Only start a jump if we are grounded and not already jumping
            if (Input.GetKeyDown(KeyCode.Space) && _isGrounded && !_isJumping)
            {
                _isJumping = true;

                // Fire the animation immediately
                if (animator != null) animator.SetTrigger("Jump");

                // Start a short coroutine to delay the physical jump
                StartCoroutine(JumpDelay());
            }
        }

        private IEnumerator JumpDelay()
        {
            // Wait for the specified anticipation time
            yield return new WaitForSeconds(jumpDelay);

            // Now apply the actual upward force
            _verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);

            _isJumping = false;
        }

        private void UpdateAnimation()
        {
            if (animator == null) return;
            float horizontal = Input.GetAxisRaw("Horizontal");
            float vertical = Input.GetAxisRaw("Vertical");
            float speed = Mathf.Clamp01(new Vector2(horizontal, vertical).magnitude);

            animator.SetFloat("Speed", speed);
            animator.SetBool("IsGrounded", _isGrounded);
            animator.SetBool("IsRunning", _isRunning);
        }

        private void RotateToward(Vector3 direction)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }
    }
}